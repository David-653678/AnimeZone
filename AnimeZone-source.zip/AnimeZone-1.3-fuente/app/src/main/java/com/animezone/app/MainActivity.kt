package com.animezone.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Navy = Color(0xFF080D1B)
private val Panel = Color(0xFF111B30)
private val PanelLight = Color(0xFF192741)
private val Blue = Color(0xFF35B8FF)
private val Muted = Color(0xFF9BAAC4)
private val White = Color(0xFFF5F8FF)

private val genreNames = listOf(
    "Acción", "Aventura", "Comedia", "Drama", "Fantasía", "Romance",
    "Ciencia ficción", "Deportes", "Suspenso", "Recuentos de la vida"
)
private val genreApi = mapOf(
    "Acción" to "Action", "Aventura" to "Adventure", "Comedia" to "Comedy",
    "Drama" to "Drama", "Fantasía" to "Fantasy", "Romance" to "Romance",
    "Ciencia ficción" to "Sci-Fi", "Deportes" to "Sports", "Suspenso" to "Thriller",
    "Recuentos de la vida" to "Slice of Life"
)

data class Anime(
    val id: Int,
    val title: String,
    val image: String,
    val banner: String,
    val score: String,
    val synopsis: String,
    val year: String,
    val episodes: String,
    val format: String,
    val status: String,
    val genres: List<String>
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnimeZoneApp() }
    }
}

@Composable
fun AnimeZoneApp() {
    var search by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf("Todos") }
    var anime by remember { mutableStateOf<List<Anime>>(emptyList()) }
    var page by remember { mutableIntStateOf(1) }
    var hasNextPage by remember { mutableStateOf(true) }
    var loading by remember { mutableStateOf(true) }
    var loadingMore by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Anime?>(null) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(search, selectedGenre, page, reload) {
        delay(if (page == 1) 350 else 0)
        if (page == 1) loading = true else loadingMore = true
        error = false
        try {
            val result = withContext(Dispatchers.IO) {
                fetchAnimePage(page, search.trim(), genreApi[selectedGenre])
            }
            anime = if (page == 1) result.first else (anime + result.first).distinctBy { it.id }
            hasNextPage = result.second
        } catch (_: Exception) {
            error = true
        }
        loading = false
        loadingMore = false
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Blue,
        onBackground = White, onSurface = White
    )) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (selected != null) {
                AnimeDetail(selected!!) { selected = null }
            } else {
                HomeScreen(
                    search = search,
                    onSearch = { search = it; page = 1 },
                    selectedGenre = selectedGenre,
                    onGenre = { selectedGenre = it; page = 1 },
                    anime = anime,
                    loading = loading,
                    loadingMore = loadingMore,
                    hasNextPage = hasNextPage,
                    error = error,
                    onRetry = { page = 1; reload++ },
                    onLoadMore = { if (!loadingMore && hasNextPage) page++ },
                    onSelect = { selected = it }
                )
            }
        }
    }
}

private suspend fun fetchAnimePage(page: Int, search: String, genre: String?): Pair<List<Anime>, Boolean> {
    val query = """
        query (${'$'}page: Int!, ${'$'}search: String, ${'$'}genres: [String]) {
          Page(page: ${'$'}page, perPage: 24) {
            pageInfo { hasNextPage }
            media(type: ANIME, isAdult: false, search: ${'$'}search, genre_in: ${'$'}genres, sort: [POPULARITY_DESC]) {
              id
              title { romaji english }
              coverImage { extraLarge large }
              bannerImage
              averageScore
              description(asHtml: false)
              seasonYear
              episodes
              format
              status
              genres
            }
          }
        }
    """.trimIndent()
    val variables = JSONObject()
        .put("page", page)
        .put("search", if (search.isBlank()) JSONObject.NULL else search)
        .put("genres", if (genre == null) JSONObject.NULL else org.json.JSONArray().put(genre))
    val payload = JSONObject().put("query", query).put("variables", variables)
    val connection = (URL("https://graphql.anilist.co").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 15000
        readTimeout = 20000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("Accept", "application/json")
        setRequestProperty("User-Agent", "AnimeZone-Android/1.3")
    }
    val responseText: String
    try {
        connection.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(payload.toString()) }
        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: throw IllegalStateException("AniList no devolvió respuesta (HTTP $status)")
        if (status !in 200..299) throw IllegalStateException("AniList respondió HTTP $status")
    } finally {
        connection.disconnect()
    }
    val pageObject = JSONObject(responseText).getJSONObject("data").getJSONObject("Page")
    val media = pageObject.getJSONArray("media")
    val hasMore = pageObject.getJSONObject("pageInfo").optBoolean("hasNextPage", false)
    val list = (0 until media.length()).map { index ->
        val item = media.getJSONObject(index)
        val titles = item.optJSONObject("title")
        val title = titles?.optString("english").orEmpty().ifBlank { titles?.optString("romaji").orEmpty() }
        val cover = item.optJSONObject("coverImage")
        val score = item.optInt("averageScore", 0)
        val genresJson = item.optJSONArray("genres")
        val genres = if (genresJson == null) emptyList() else (0 until genresJson.length()).map { genresJson.optString(it) }
        Anime(
            id = item.optInt("id"),
            title = title.ifBlank { "Anime sin título" },
            image = cover?.optString("extraLarge").orEmpty().ifBlank { cover?.optString("large").orEmpty() },
            banner = item.optString("bannerImage").ifBlank { cover?.optString("large").orEmpty() },
            score = if (score > 0) String.format(Locale.US, "%.1f", score / 10.0) else "—",
            synopsis = item.optString("description").ifBlank { "Sin descripción disponible." },
            year = item.optInt("seasonYear").takeIf { it > 0 }?.toString() ?: "Año desconocido",
            episodes = item.optInt("episodes").takeIf { it > 0 }?.toString() ?: "Por confirmar",
            format = item.optString("format").replace('_', ' ').ifBlank { "Anime" },
            status = item.optString("status").replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() },
            genres = genres
        )
    }
    return list to hasMore
}

@Composable
private fun HomeScreen(
    search: String, onSearch: (String) -> Unit,
    selectedGenre: String, onGenre: (String) -> Unit,
    anime: List<Anime>, loading: Boolean, loadingMore: Boolean,
    hasNextPage: Boolean, error: Boolean, onRetry: () -> Unit,
    onLoadMore: () -> Unit, onSelect: (Anime) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 18.dp, bottom = 14.dp)) {
                    Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Blue), contentAlignment = Alignment.Center) {
                        Text("AZ", color = Navy, fontWeight = FontWeight.Black, fontSize = 17.sp)
                    }
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text("AnimeZone", color = White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Descubre tu próximo anime", color = Muted, fontSize = 11.sp)
                    }
                    Text("ANIME", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedTextField(
                    value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Buscar anime...", color = Muted) }, singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = White, unfocusedTextColor = White,
                        focusedBorderColor = Blue, unfocusedBorderColor = PanelLight,
                        focusedContainerColor = Panel, unfocusedContainerColor = Panel,
                        cursorColor = Blue
                    )
                )
            }
        }
        if (anime.isNotEmpty() && search.isBlank() && selectedGenre == "Todos" && !loading) {
            item { FeaturedAnime(anime.first(), onSelect) }
            item { SectionTitle("Populares ahora", "Tendencias de AniList") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(anime.take(10), key = { it.id }) { PopularCard(it, onSelect) }
                }
            }
        }
        item {
            Column {
                SectionTitle(if (search.isBlank()) "Explora anime" else "Resultados", "Catálogo de AniList")
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { GenreChip("Todos", selectedGenre == "Todos") { onGenre("Todos") } }
                    items(genreNames) { genre -> GenreChip(genre, selectedGenre == genre) { onGenre(genre) } }
                }
            }
        }
        if (loading && anime.isEmpty()) {
            item { Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Blue) } }
        } else if (error && anime.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No se pudo cargar el catálogo.", color = White)
                    Text("Comprueba tu conexión e inténtalo de nuevo.", color = Muted, fontSize = 12.sp)
                    TextButton(onClick = onRetry) { Text("Reintentar") }
                }
            }
        } else if (anime.isEmpty() && !loading) {
            item { Text("No se encontraron resultados.", color = Muted, modifier = Modifier.padding(20.dp)) }
        } else {
            items(anime.chunked(2), key = { row -> row.firstOrNull()?.id ?: 0 }) { row ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { item -> Box(Modifier.weight(1f)) { AnimeGridCard(item) { onSelect(item) } } }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            item {
                if (hasNextPage) {
                    Button(
                        onClick = onLoadMore, enabled = !loadingMore,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Navy),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (loadingMore) CircularProgressIndicator(Modifier.size(18.dp), color = Navy, strokeWidth = 2.dp)
                        else Text("Cargar más animes", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Text("Has llegado al final de los resultados.", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(16.dp))
                }
            }
        }
        item {
            Text("Información y catálogo proporcionados por AniList. AnimeZone no aloja episodios.",
                color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        }
    }
}

@Composable
private fun FeaturedAnime(anime: Anime, onSelect: (Anime) -> Unit) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(205.dp).clip(RoundedCornerShape(20.dp)).clickable { onSelect(anime) }) {
        AsyncImage(model = anime.banner.ifBlank { anime.image }, contentDescription = anime.title, modifier = Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE050914)))))
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            Text("DESTACADO", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
            Text(anime.title, color = White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("⭐ ${anime.score}  •  ${anime.year}", color = White, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Text(title, color = White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun PopularCard(anime: Anime, onSelect: (Anime) -> Unit) {
    Column(Modifier.width(112.dp).clickable { onSelect(anime) }) {
        AsyncImage(model = anime.image, contentDescription = anime.title,
            modifier = Modifier.fillMaxWidth().height(155.dp).clip(RoundedCornerShape(12.dp)))
        Spacer(Modifier.height(6.dp))
        Text(anime.title, color = White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text("⭐ ${anime.score}", color = Blue, fontSize = 11.sp)
    }
}

@Composable
private fun AnimeGridCard(anime: Anime, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Panel).clickable(onClick = onClick).padding(8.dp)) {
        AsyncImage(model = anime.image, contentDescription = anime.title,
            modifier = Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(11.dp)))
        Spacer(Modifier.height(8.dp))
        Text(anime.title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text("⭐ ${anime.score}", color = Blue, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        Text(anime.year, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun AnimeDetail(anime: Anime, onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Box(Modifier.fillMaxWidth().height(270.dp)) {
                AsyncImage(model = anime.banner.ifBlank { anime.image }, contentDescription = null, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000000), Navy))))
                Text("‹  Volver", color = White, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopStart).padding(18.dp).clip(RoundedCornerShape(10.dp))
                        .background(Color(0x99080D1B)).clickable { onBack() }.padding(horizontal = 12.dp, vertical = 9.dp))
            }
        }
        item {
            Row(Modifier.padding(horizontal = 18.dp).offset(y = (-54).dp), verticalAlignment = Alignment.Bottom) {
                AsyncImage(model = anime.image, contentDescription = anime.title,
                    modifier = Modifier.width(112.dp).height(158.dp).clip(RoundedCornerShape(13.dp)))
                Column(Modifier.padding(start = 13.dp, bottom = 5.dp).weight(1f)) {
                    Text(anime.title, color = White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text("⭐ ${anime.score}  •  ${anime.year}", color = Blue, fontSize = 12.sp)
                }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 18.dp).offset(y = (-35).dp)) {
                Text("INFORMACIÓN", color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("${anime.format}  •  ${anime.status}  •  ${anime.episodes} episodios", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                if (anime.genres.isNotEmpty()) Text(anime.genres.joinToString("  ·  "), color = White, fontSize = 12.sp)
                Spacer(Modifier.height(18.dp))
                Text("Sinopsis", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(anime.synopsis.replace(Regex("<[^>]*>"), "").replace("&quot;", "\""), color = Muted, fontSize = 14.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 8.dp))
                Spacer(Modifier.height(18.dp))
                Text("Episodios", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("La información de episodios y la reproducción se incorporarán en una próxima actualización, usando fuentes con autorización de distribución.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 7.dp))
            }
        }
    }
}

@Composable
private fun GenreChip(label: String, active: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(50), color = if (active) Blue else PanelLight) {
        Text(label, color = if (active) Navy else White, fontSize = 12.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp))
    }
}
