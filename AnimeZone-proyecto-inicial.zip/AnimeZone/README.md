# AnimeZone — versión inicial

Proyecto Android nativo en Kotlin + Jetpack Compose. Interfaz azul/negro, búsqueda de anime y favoritos locales.

## Abrir y compilar
1. Instala Android Studio en un computador.
2. Abre esta carpeta como proyecto.
3. Usa JDK 17 y deja que Gradle sincronice.
4. En Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración aparecerá en `app/build/outputs/apk/debug/app-debug.apk`.

## Qué incluye esta versión
- Búsqueda de catálogo mediante la API pública de Jikan (datos de MyAnimeList).
- Vista de detalles básica.
- Favoritos guardados en el dispositivo.
- Tema oscuro azul y negro.

## Importante sobre el contenido
Jikan aporta metadatos; no aloja episodios ni concede derechos de reproducción. Esta versión no incluye streams no autorizados ni anuncios. Para añadir reproducción, se deben integrar enlaces o reproductores de proveedores que autoricen la distribución/visualización de su contenido. Los anuncios deben añadirse mediante una red publicitaria cumpliendo sus políticas y las normas de privacidad aplicables.

## Limitaciones actuales
La primera versión aún no incluye imágenes en tarjetas, temporadas/episodios desde una fuente autorizada ni reproducción dentro de la app. Esas funciones se agregan en siguientes etapas.
