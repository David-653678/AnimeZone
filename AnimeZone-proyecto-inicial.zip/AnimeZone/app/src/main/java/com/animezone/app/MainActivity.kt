package com.animezone.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Navy = Color(0xFF071426)
private val Panel = Color(0xFF10243D)
private val Blue = Color(0xFF168BFF)
private val TextMain = Color(0xFFF2F7FF)

data class Anime(
    val id: Int,
    val title: String,
    val synopsis: String,
    val image: String,
    val episodes: Int?,
    val score: Double?
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnimeZoneApp(this) }
    }
}

@Composable
fun AnimeZoneApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("animezone", Context.MODE_PRIVATE) }
    val favorites = remember {
        mutableStateListOf<Int>().apply {
            addAll(prefs.getStringSet("favorites", emptySet())!!.mapNotNull { it.toIntOrNull() })
        }
    }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Anime>>(emptyList()) }
    var selected by remember { mutableStateOf<Anime?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showFavorites by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun search(term: String) {
        scope.launch {
            loading = true
            error = null
            try {
                results = withContext(Dispatchers.IO) { searchAnime(term) }
            } catch (e: Exception) {
                error = "No se pudo cargar el catálogo. Revisa tu conexión e inténtalo de nuevo."
            } finally {
                loading = false
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue,
            background = Navy,
            surface = Panel,
            onBackground = TextMain,
            onSurface = TextMain
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ANIME", color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Text("ZONE", color = Blue, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { showFavorites = !showFavorites; selected = null }) {
                        Text(if (showFavorites) "Catálogo" else "♥ Favoritos", color = Blue)
                    }
                }
                Text("Tu próximo anime empieza aquí", color = Color.LightGray, fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))

                if (selected != null) {
                    val anime = selected!!
                    TextButton(onClick = { selected = null }) { Text("← Volver", color = Blue) }
                    Text(anime.title, color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Episodios: ${anime.episodes ?: "Por confirmar"}   •   Puntuación: ${anime.score ?: "N/D"}",
                        color = Color.LightGray)
                    Spacer(Modifier.height(12.dp))
                    Text(anime.synopsis.ifBlank { "Sin sinopsis disponible." }, color = TextMain)
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = {
                            val isFav = favorites.contains(anime.id)
                            if (isFav) favorites.remove(anime.id) else favorites.add(anime.id)
                            prefs.edit().putStringSet("favorites", favorites.map { it.toString() }.toSet()).apply()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Blue)
                    ) { Text(if (favorites.contains(anime.id)) "Quitar de favoritos" else "Añadir a favoritos") }
                    Spacer(Modifier.height(12.dp))
                    Text("Reproducción: esta versión inicial muestra el catálogo. Los episodios se conectarán a proveedores oficiales gratuitos cuando exista una fuente autorizada disponible.",
                        color = Color.LightGray, fontSize = 13.sp)
                } else {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Buscar anime") },
                        placeholder = { Text("Ej. Naruto, One Piece...") },
                        trailingIcon = {
                            TextButton(onClick = { showFavorites = false; search(query) }) { Text("Buscar") }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Blue,
                            focusedLabelColor = Blue,
                            cursorColor = Blue
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                    if (showFavorites) {
                        Text("Tus favoritos", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Text("Explorar anime", color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    if (loading) {
                        Box(Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = Blue)
                        }
                    }
                    error?.let { Text(it, color = Color(0xFFFF8A80), modifier = Modifier.padding(8.dp)) }
                    val visible = if (showFavorites) results.filter { favorites.contains(it.id) } else results
                    if (visible.isEmpty() && !loading) {
                        Text(
                            if (showFavorites) "Todavía no tienes favoritos. Busca un anime y guárdalo con ♥."
                            else "Busca un anime para empezar. El catálogo usa datos públicos de Jikan/MyAnimeList.",
                            color = Color.LightGray,
                            modifier = Modifier.padding(top = 14.dp)
                        )
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(visible, key = { it.id }) { anime ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { selected = anime },
                                colors = CardDefaults.cardColors(containerColor = Panel),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Column(Modifier.padding(14.dp)) {
                                    Text(anime.title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        "Episodios: ${anime.episodes ?: "N/D"}   •   ⭐ ${anime.score ?: "N/D"}",
                                        color = Color.LightGray,
                                        fontSize = 12.sp
                                    )
                                    Spacer(Modifier.height(5.dp))
                                    Text(anime.synopsis.take(180).ifBlank { "Sin sinopsis disponible." },
                                        color = TextMain, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun searchAnime(term: String): List<Anime> {
    val safe = java.net.URLEncoder.encode(term.ifBlank { "popular" }, "UTF-8")
    val connection = (URL("https://api.jikan.moe/v4/anime?q=$safe&limit=20").openConnection() as HttpURLConnection)
    connection.connectTimeout = 12000
    connection.readTimeout = 12000
    connection.setRequestProperty("User-Agent", "AnimeZone-Android/0.1")
    try {
        val body = connection.inputStream.bufferedReader().use { it.readText() }
        val array = JSONObject(body).getJSONArray("data")
        return (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            Anime(
                id = item.optInt("mal_id"),
                title = item.optString("title", "Anime sin título"),
                synopsis = item.optString("synopsis", ""),
                image = item.optJSONObject("images")?.optJSONObject("jpg")?.optString("image_url", "") ?: "",
                episodes = if (item.isNull("episodes")) null else item.optInt("episodes"),
                score = if (item.isNull("score")) null else item.optDouble("score")
            )
        }
    } finally {
        connection.disconnect()
    }
}
