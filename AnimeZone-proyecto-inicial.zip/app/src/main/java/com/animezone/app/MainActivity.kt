package com.animezone.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder
import java.net.HttpURLConnection

private val Navy = Color(0xFF080D1B)
private val Panel = Color(0xFF111B30)
private val Blue = Color(0xFF35B8FF)
private val Muted = Color(0xFF9BAAC4)

data class Anime(val id: Int, val title: String, val image: String, val score: String, val synopsis: String)

private val genreIds = linkedMapOf(
    "Acción" to 1, "Romance" to 22, "Comedia" to 4, "Fantasía" to 10,
    "Escolares" to 8, "Isekai" to 10, "Drama" to 8, "Suspenso" to 41,
    "Deportes" to 30, "Recuentos de la vida" to 36, "Ciencia ficción" to 24,
    "Aventura" to 2
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnimeZoneApp() }
    }
}

@Composable
fun AnimeZoneApp() {
    var search by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf("Todos") }
    var anime by remember { mutableStateOf<List<Anime>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Anime?>(null) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(search, selectedGenre, reload) {
        delay(400)
        loading = true
        error = false
        try {
            anime = withContext(Dispatchers.IO) {
                val url = buildString {
                    append("https://api.jikan.moe/v4/anime?limit=24&order_by=popularity&sort=asc")
                    if (search.isNotBlank()) append("&q=${URLEncoder.encode(search, "UTF-8")}")
                    genreIds[selectedGenre]?.let { append("&genres=$it") }
                }
                val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10000
                    readTimeout = 15000
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "AnimeZone-Android/1.1")
                }
                val data = try {
                    val status = connection.responseCode
                    if (status != HttpURLConnection.HTTP_OK) {
                        throw IllegalStateException("Servidor de catálogo respondió: $status")
                    }
                    val response = connection.inputStream.bufferedReader().use { it.readText() }
                    JSONObject(response).getJSONArray("data")
                } finally {
                    connection.disconnect()
                }
                (0 until data.length()).map { i ->
                    val a = data.getJSONObject(i)
                    val jpg = a.optJSONObject("images")?.optJSONObject("jpg")
                    Anime(a.optInt("mal_id"), a.optString("title"),
                        jpg?.optString("large_image_url").orEmpty(),
                        if (a.isNull("score")) "—" else a.optString("score"),
                        a.optString("synopsis"))
                }
            }
        } catch (_: Exception) { error = true }
        loading = false
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Navy, surface = Panel, primary = Blue)) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (selected != null) {
                Column(Modifier.fillMaxSize().padding(18.dp)) {
                    Text("‹  Volver", color = Blue, modifier = Modifier.clickable { selected = null }.padding(vertical = 8.dp))
                    AsyncImage(selected!!.image, null, Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(18.dp)))
                    Spacer(Modifier.height(14.dp))
                    Text(selected!!.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("⭐ ${selected!!.score}", color = Blue, modifier = Modifier.padding(vertical = 8.dp))
                    Text(selected!!.synopsis.ifBlank { "Sin sinopsis disponible." }, color = Muted)
                }
            } else {
                Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 14.dp, bottom = 12.dp)) {
                        Icon(painterResource(R.drawable.animezone_logo), null, tint = Color.Unspecified, modifier = Modifier.size(48.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("AnimeZone", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Tu catálogo de anime", color = Muted, fontSize = 12.sp)
                        }
                    }
                    OutlinedTextField(
                        value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Buscar anime...", color = Muted) }, singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Blue, unfocusedBorderColor = Panel,
                            focusedContainerColor = Panel, unfocusedContainerColor = Panel
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { GenreChip("Todos", selectedGenre == "Todos") { selectedGenre = "Todos" } }
                        rowItems(genreIds.keys.toList()) { g ->
                            GenreChip(g, selectedGenre == g) { selectedGenre = g }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Explora anime", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    when {
                        loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Blue) }
                        error -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("No se pudo conectar con el catálogo.", color = Color.White)
                                Text("Comprueba tu conexión y vuelve a intentarlo.", color = Muted, fontSize = 12.sp)
                                TextButton(onClick = { reload++ }) { Text("Reintentar") }
                            }
                        }
                        anime.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No se encontraron resultados.", color = Muted) }
                        else -> LazyVerticalGrid(
                            columns = GridCells.Fixed(2), contentPadding = PaddingValues(bottom = 18.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(anime) { item ->
                                Column(
                                    Modifier.clip(RoundedCornerShape(16.dp)).background(Panel)
                                        .clickable { selected = item }.padding(8.dp)
                                ) {
                                    AsyncImage(item.image, item.title, Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(12.dp)))
                                    Spacer(Modifier.height(8.dp))
                                    Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text("⭐ ${item.score}", color = Blue, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                                }
                            }
                        }
                    }
                    Text("Catálogo informativo actualizado desde Jikan API / MyAnimeList. No reproduce episodios.",
                        color = Muted, fontSize = 10.sp, modifier = Modifier.padding(vertical = 6.dp))
                }
            }
        }
    }
}

@Composable
fun GenreChip(label: String, active: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(50), color = if (active) Blue else Panel) {
        Text(label, color = if (active) Navy else Color.White, fontSize = 12.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp))
    }
}
