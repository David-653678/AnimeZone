package com.animezone.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder
import java.net.HttpURLConnection

private val Navy = Color(0xFF080D1B)
private val Panel = Color(0xFF111B30)
private val Blue = Color(0xFF35B8FF)
private val Muted = Color(0xFF9BAAC4)

data class Anime(val id: Int, val title: String, val image: String, val score: String, val synopsis: String)

private val aniListGenres = mapOf(
    "Acción" to "Action",
    "Romance" to "Romance",
    "Comedia" to "Comedy",
    "Fantasía" to "Fantasy",
    "Drama" to "Drama",
    "Suspenso" to "Thriller",
    "Deportes" to "Sports",
    "Recuentos de la vida" to "Slice of Life",
    "Ciencia ficción" to "Sci-Fi",
    "Aventura" to "Adventure"
)
private val aniListTags = mapOf(
    "Escolares" to "School",
    "Isekai" to "Isekai"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnimeZoneApp() }
    }
}

@Composable
fun AnimeZoneApp() {
    var search by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf("Todos") }
    var anime by remember { mutableStateOf<List<Anime>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Anime?>(null) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(search, selectedGenre, reload) {
        delay(400)
        loading = true
        error = false
        try {
            anime = withContext(Dispatchers.IO) {
                val query = """
                    query (${'$'}page: Int!, ${'$'}search: String, ${'$'}genres: [String], ${'$'}tags: [String]) {
                      Page(page: ${'$'}page, perPage: 24) {
                        media(
                          type: ANIME,
                          isAdult: false,
                          search: ${'$'}search,
                          genre_in: ${'$'}genres,
                          tag_in: ${'$'}tags,
                          sort: [POPULARITY_DESC]
                        ) {
                          id
                          title { romaji english }
                          coverImage { extraLarge large }
                          averageScore
                          description(asHtml: false)
                        }
                      }
                    }
                """.trimIndent()

                val variables = JSONObject()
                    .put("page", 1)
                    .put("search", if (search.isBlank()) JSONObject.NULL else search.trim())
                    .put("genres", aniListGenres[selectedGenre]?.let { org.json.JSONArray().put(it) } ?: JSONObject.NULL)
                    .put("tags", aniListTags[selectedGenre]?.let { org.json.JSONArray().put(it) } ?: JSONObject.NULL)

                val payload = JSONObject()
                    .put("query", query)
                    .put("variables", variables)

                val connection = (URL("https://graphql.anilist.co").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "AnimeZone-Android/1.2")
                }

                val responseText: String
                try {
                    connection.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(payload.toString()) }
                    val status = connection.responseCode
                    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                    responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IllegalStateException("AniList no devolvió respuesta (HTTP $status)")
                    if (status !in 200..299) {
                        throw IllegalStateException("AniList respondió HTTP $status")
                    }
                } finally {
                    connection.disconnect()
                }

                val media = JSONObject(responseText)
                    .getJSONObject("data")
                    .getJSONObject("Page")
                    .getJSONArray("media")

                (0 until media.length()).map { i ->
                    val item = media.getJSONObject(i)
                    val titles = item.optJSONObject("title")
                    val title = titles?.optString("english").orEmpty()
                        .ifBlank { titles?.optString("romaji").orEmpty() }
                    val cover = item.optJSONObject("coverImage")
                    val scoreValue = item.optInt("averageScore", 0)
                    Anime(
                        item.optInt("id"),
                        title.ifBlank { "Anime sin título" },
                        cover?.optString("extraLarge").orEmpty().ifBlank { cover?.optString("large").orEmpty() },
                        if (scoreValue > 0) String.format(java.util.Locale.US, "%.1f/10", scoreValue / 10.0) else "—",
                        item.optString("description").ifBlank { "Sin descripción disponible." }
                    )
                }
            }
        } catch (_: Exception) { error = true }
        loading = false
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Navy, surface = Panel, primary = Blue)) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            if (selected != null) {
                Column(Modifier.fillMaxSize().padding(18.dp)) {
                    Text("‹  Volver", color = Blue, modifier = Modifier.clickable { selected = null }.padding(vertical = 8.dp))
                    AsyncImage(selected!!.image, null, Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(18.dp)))
                    Spacer(Modifier.height(14.dp))
                    Text(selected!!.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("⭐ ${selected!!.score}", color = Blue, modifier = Modifier.padding(vertical = 8.dp))
                    Text(selected!!.synopsis.ifBlank { "Sin sinopsis disponible." }, color = Muted)
                }
            } else {
                Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 14.dp, bottom = 12.dp)) {
                        Icon(painterResource(R.drawable.animezone_logo), null, tint = Color.Unspecified, modifier = Modifier.size(48.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("AnimeZone", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Tu catálogo de anime", color = Muted, fontSize = 12.sp)
                        }
                    }
                    OutlinedTextField(
                        value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Buscar anime...", color = Muted) }, singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Blue, unfocusedBorderColor = Panel,
                            focusedContainerColor = Panel, unfocusedContainerColor = Panel
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { GenreChip("Todos", selectedGenre == "Todos") { selectedGenre = "Todos" } }
                        rowItems(genreIds.keys.toList()) { g ->
                            GenreChip(g, selectedGenre == g) { selectedGenre = g }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Explora anime", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    when {
                        loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Blue) }
                        error -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("No se pudo conectar con el catálogo.", color = Color.White)
                                Text("Comprueba tu conexión y vuelve a intentarlo.", color = Muted, fontSize = 12.sp)
                                TextButton(onClick = { reload++ }) { Text("Reintentar") }
                            }
                        }
                        anime.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No se encontraron resultados.", color = Muted) }
                        else -> LazyVerticalGrid(
                            columns = GridCells.Fixed(2), contentPadding = PaddingValues(bottom = 18.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(anime) { item ->
                                Column(
                                    Modifier.clip(RoundedCornerShape(16.dp)).background(Panel)
                                        .clickable { selected = item }.padding(8.dp)
                                ) {
                                    AsyncImage(item.image, item.title, Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(12.dp)))
                                    Spacer(Modifier.height(8.dp))
                                    Text(item.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text("⭐ ${item.score}", color = Blue, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                                }
                            }
                        }
                    }
                    Text("Catálogo informativo actualizado desde AniList. No reproduce episodios.",
                        color = Muted, fontSize = 10.sp, modifier = Modifier.padding(vertical = 6.dp))
                }
            }
        }
    }
}

@Composable
fun GenreChip(label: String, active: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, shape = RoundedCornerShape(50), color = if (active) Blue else Panel) {
        Text(label, color = if (active) Navy else Color.White, fontSize = 12.sp,
            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp))
    }
}
